﻿using MassTransit;
using OrderService.Models;
using PaymentService.Models;
namespace PaymentService.Consumers;

public class PaymentFailedConsumer : IConsumer<IPaymentFailed>
{
    public async Task Consume(ConsumeContext<IPaymentFailed> context)
    {
        var orderId = context.Message.OrderId;
        var reason = context.Message.Reason;

        await Console.Out.WriteLineAsync($"Order Id - {orderId} Payment ProcessFailed! Reason - {reason}!");

        // Publish event for order cancellation
        await context.Publish<IOrderCancelled>(new
        {
            OrderId = orderId,
            Reason = reason
        });
    }
}
