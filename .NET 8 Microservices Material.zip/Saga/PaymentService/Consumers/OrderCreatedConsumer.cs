﻿using MassTransit;
using OrderService.Models;
using PaymentService.Models;

namespace PaymentService.Consumers;

public class OrderCreatedConsumer : IConsumer<IOrderCreated>
{
    public async Task Consume(ConsumeContext<IOrderCreated> context)
    {
        var orderId = context.Message.OrderId;
        var amount = context.Message.Amount;

        try
        {
            // Simulate payment processing
            if (amount < 50) // Simulate a failure for amounts < 50
                throw new Exception("Payment failed");

            // Publish event for successful payment
            await context.Publish<IPaymentProcessed>(new
            {
                OrderId = orderId,
                Amount = amount
            });
        }
        catch (Exception)
        {
            // Publish event for payment failure
            await context.Publish<IPaymentFailed>(new
            {
                OrderId = orderId,
                Amount = amount,
                Reason = "Insufficient funds" // example reason
            });
        }
    }
}