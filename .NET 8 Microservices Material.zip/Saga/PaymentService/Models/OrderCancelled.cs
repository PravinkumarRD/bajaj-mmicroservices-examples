﻿namespace OrderService.Models;

public interface IOrderCancelled
{
    Guid OrderId { get; }
    string Reason { get; }
}
