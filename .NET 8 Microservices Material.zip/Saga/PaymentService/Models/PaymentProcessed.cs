﻿namespace PaymentService.Models;

public interface IPaymentProcessed
{
    Guid OrderId { get; }
    double Amount { get; }
}
