﻿namespace PaymentService.Models;

public interface IPaymentFailed
{
    Guid OrderId { get; }
    double Amount { get; }
    string Reason { get; }
}
