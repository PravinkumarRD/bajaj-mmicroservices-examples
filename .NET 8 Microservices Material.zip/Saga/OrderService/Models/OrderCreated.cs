﻿namespace OrderService.Models;

public interface IOrderCreated
{
    Guid OrderId { get; }
    double Amount { get; }
}
