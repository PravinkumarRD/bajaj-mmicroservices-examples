﻿using MassTransit;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using OrderService.Models;

namespace OrderService.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OrderController(IPublishEndpoint _publishEndpoint) : ControllerBase
    {

        [HttpPost]
        public async Task<IActionResult> CreateOrder(double amount)
        {
            var orderId = Guid.NewGuid();
            await _publishEndpoint.Publish<IOrderCreated>(new
            {
                OrderId = orderId,
                Amount = amount
            });

            return Ok(new { OrderId = orderId });
        }
    }
}
