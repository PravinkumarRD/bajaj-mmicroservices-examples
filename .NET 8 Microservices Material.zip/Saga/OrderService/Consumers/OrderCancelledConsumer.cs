﻿using MassTransit;
using OrderService.Models;

namespace OrderService.Consumers;

public class OrderCancelledConsumer : IConsumer<IOrderCancelled>
{
    public async Task Consume(ConsumeContext<IOrderCancelled> context)
    {
        var orderId = context.Message.OrderId;
        var reason = context.Message.Reason;

        await Console.Out.WriteLineAsync($"Rollbacking the Transaction for Order Id - {orderId} which has been cancelled due to Reason - {reason}!");
    }
}