﻿using Domain.Entities;

namespace Domain.Contracts;

public interface IEventRepository
{
    //Query Operations [DQL - Select]
    Task<List<Event>> GetAllAsync();
    Task<Event> GetDetailsByIdAsync(int id);
    //Command Operations [DML - Insert/Update/Delete]
    Task<int> AddAsync(Event entity);
    Task<int> UpdateAsync(Event entity);
    Task<int> DeleteAsync(int id);
}
