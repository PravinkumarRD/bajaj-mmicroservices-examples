﻿using Domain.Primitives;

namespace Domain.Events;

public sealed class NewTrainingPublishedDomainEvent : DomainEvent
{
    public string HrManagerEmail { get; set; } = string.Empty;
    public string Department { get; set; } = string.Empty;
    public string CreatedBy { get; set; } = string.Empty;
    public string EventName { get; set; } = string.Empty;

}
