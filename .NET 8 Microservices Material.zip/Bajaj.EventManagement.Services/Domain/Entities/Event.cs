﻿using Domain.Events;
using Domain.Primitives;
using Domain.ValueObjects;
using System.ComponentModel.DataAnnotations;

namespace Domain.Entities;

public class Event : AggregateRoot
{
    public int EventId { get; private set; }
    [Required(ErrorMessage = "Event Name is a required field!")]
    [MaxLength(100)]
    public string EventName { get; private set; } = string.Empty;
    public EventDateRange EventPeriod { get; private set; }
    [MaxLength(500)]
    public string EventDescription { get; private set; } = string.Empty;
    public Address Venu { get; private set; }
    public int SeatsFilled { get; private set; }
    public decimal Fees { get; private set; }
    [MaxLength(200)]
    public string? Logo { get; private set; }

    public static Event Create(string eventName, string eventDescription, EventDateRange eventPeriod, Address venu, int seatsFilled, decimal fees, string? logo)
    {
        var newEvent = new Event() { EventName = eventName, EventDescription = eventDescription, EventPeriod = eventPeriod, Venu = venu, SeatsFilled = seatsFilled, Fees = fees, Logo = logo };

        newEvent.Raise(new NewTrainingPublishedDomainEvent());

        return newEvent;
    }

}
