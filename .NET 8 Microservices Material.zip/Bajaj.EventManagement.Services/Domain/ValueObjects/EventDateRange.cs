﻿using Microsoft.EntityFrameworkCore;

namespace Domain.ValueObjects;

[Owned]
public class EventDateRange
{
    public DateTime StartDate { get; set; }
    public DateTime EndDate { get; set; }

    public static EventDateRange Create(DateTime startDate, DateTime endDate)
    {
        if (endDate < startDate)
        {
            throw new ArgumentException("End Date must be greater than start date");
        }
        return new EventDateRange() { StartDate = startDate, EndDate = endDate };
    }
}