﻿using System.ComponentModel.DataAnnotations.Schema;

namespace Domain.Primitives;

public abstract class AggregateRoot
{
    private readonly List<DomainEvent> _domainEvents = new();
    protected AggregateRoot()
    {

    }
    [NotMapped]
    public IReadOnlyCollection<DomainEvent> Events => _domainEvents;

    protected void Raise(DomainEvent domainEvent)
    {
        _domainEvents.Add(domainEvent);
    }
}
