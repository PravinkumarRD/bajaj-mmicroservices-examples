﻿using MediatR;

namespace Domain.Primitives;

public abstract class DomainEvent:INotification
{
}
