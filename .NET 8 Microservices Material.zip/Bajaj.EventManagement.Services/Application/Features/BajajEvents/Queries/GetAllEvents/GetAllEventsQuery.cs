﻿using Domain.Entities;
using MediatR;

namespace Application.Features.BajajEvents.Queries.GetAllEvents;

public record GetAllEventsQuery : IRequest<List<Event>> { }

