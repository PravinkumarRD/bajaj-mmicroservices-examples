﻿using Domain.Contracts;
using Domain.Entities;
using MediatR;

namespace Application.Features.BajajEvents.Queries.GetAllEvents;

public class GetAllEventsQueryHandler(IEventRepository _repository) : IRequestHandler<GetAllEventsQuery, List<Event>>
{
    public async Task<List<Event>> Handle(GetAllEventsQuery request, CancellationToken cancellationToken)
    {
        return await _repository.GetAllAsync();
    }
}
