﻿using Domain.Contracts;
using Domain.Entities;
using MediatR;

namespace Application.Features.BajajEvents.Queries.GetEventDetails;

public class GetEventDetailsQueryHandler (IEventRepository _repository): IRequestHandler<GetEventDetailsQuery, Event>
{
    public async Task<Event> Handle(GetEventDetailsQuery request, CancellationToken cancellationToken)
    {
        return await _repository.GetDetailsByIdAsync(request.EventId);
    }
}
