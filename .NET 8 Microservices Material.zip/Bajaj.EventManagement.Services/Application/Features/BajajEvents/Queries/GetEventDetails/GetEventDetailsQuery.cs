﻿using Domain.Entities;
using MediatR;

namespace Application.Features.BajajEvents.Queries.GetEventDetails;

public class GetEventDetailsQuery : IRequest<Event>
{
    public int EventId { get; set; }
}
