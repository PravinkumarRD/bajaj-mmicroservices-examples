﻿using MediatR;

namespace Application.Features.BajajEvents.Commands.CreateEvent;

public class CreateEventCommand:IRequest<int>
{
    public string Country { get; set; } = string.Empty;
    public string Line1 { get; set; } = string.Empty;
    public string Line2 { get; set; } = string.Empty;
    public string City { get; set; } = string.Empty;
    public string State { get; set; } = string.Empty;
    public string ZipCode { get; set; } = string.Empty;
    public string EventName { get; set; } = string.Empty;
    public string EventDescription { get; set; } = string.Empty;
    public int SeatsFilled { get; set; }
    public decimal Fees { get; set; }
    public DateTime StartDate { get; set; }
    public DateTime EndDate { get; set; }
    public string? Logo { get; set; }
}
