﻿using Domain.Events;
using MediatR;

namespace Application.Features.BajajEvents.Commands.CreateEvent;

public class NewTrainingPublishedDomainEventHandler : INotificationHandler<NewTrainingPublishedDomainEvent>
{
    public async Task Handle(NewTrainingPublishedDomainEvent notification, CancellationToken cancellationToken)
    {
        await Console.Out.WriteLineAsync($"New Event - {notification.EventName} has been published by {notification.CreatedBy}! For the department {notification.Department}! Incase you have any query, please write  an Email to - {notification.HrManagerEmail}!");
    }
}
