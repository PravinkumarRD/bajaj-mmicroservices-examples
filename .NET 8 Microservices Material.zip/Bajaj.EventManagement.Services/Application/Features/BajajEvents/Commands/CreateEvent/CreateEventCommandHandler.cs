﻿using Domain.Contracts;
using Domain.Entities;
using Domain.Events;
using Domain.ValueObjects;
using MediatR;

namespace Application.Features.BajajEvents.Commands.CreateEvent;

public class CreateEventCommandHandler(IEventRepository _repository,IPublisher _publisher) : IRequestHandler<CreateEventCommand, int>
{
    public async Task<int> Handle(CreateEventCommand request, CancellationToken cancellationToken)
    {
        var address = Address.Create(request.Line1, request.Line2, request.City, request.State, request.ZipCode, request.Country);
        var period = EventDateRange.Create(request.StartDate, request.EndDate);
        var @event = Event.Create(request.EventName, request.EventDescription, period, address, request.SeatsFilled, request.Fees, request.Logo);
        var result = await _repository.AddAsync(@event);
        if (result > 0)
        {
            await _publisher.Publish(new NewTrainingPublishedDomainEvent() { 
                CreatedBy="Varun Patil",
                Department="Frontend Development",
                HrManagerEmail="varun.patil@bajaj.com",
                EventName=request.EventName
            });
        }
        return result;
    }
}
