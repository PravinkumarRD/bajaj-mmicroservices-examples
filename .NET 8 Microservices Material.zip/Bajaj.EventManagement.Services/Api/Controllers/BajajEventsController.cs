﻿using Api.Dtos;
using Application.Features.BajajEvents.Commands.CreateEvent;
using Application.Features.BajajEvents.Queries.GetAllEvents;
using Application.Features.BajajEvents.Queries.GetEventDetails;
using DE = Domain.Entities;
using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MassTransit;

namespace Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BajajEventsController(IMediator _mediator, IPublishEndpoint _publishEndpoint) : ControllerBase
    {
        [HttpGet]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<ActionResult<IEnumerable<DE.Event>>> Get()
        {
            try
            {
                var events = await _mediator.Send(new GetAllEventsQuery());
                if (events.Any())
                {
                    return Ok(events);
                }
                else
                {
                    return NotFound();
                }
            }
            catch (Exception)
            {
                return BadRequest();
            }
        }
        [HttpGet("{id:int}")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<ActionResult<DE.Event>> GetDetails(int id)
        {
            try
            {
                var @event = await _mediator.Send(new GetEventDetailsQuery() { EventId = id });
                if (@event != null)
                {
                    return Ok(@event);
                }
                else
                {
                    return NotFound();
                }
            }
            catch (Exception)
            {
                return BadRequest();
            }
        }
        [HttpPost]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<ActionResult<DE.Event>> Post(EventDto eventDto)
        {
            try
            {
                var result = await _mediator.Send(new CreateEventCommand()
                {
                    City = eventDto.City,
                    Country = eventDto.Country,
                    EndDate = eventDto.EndDate,
                    EventDescription = eventDto.EventDescription,
                    EventName = eventDto.EventName,
                    Fees = eventDto.Fees,
                    Line1 = eventDto.Line1,
                    Line2 = eventDto.Line2,
                    Logo = eventDto.Logo,
                    SeatsFilled = eventDto.SeatsFilled,
                    StartDate = eventDto.StartDate,
                    State = eventDto.State,
                    ZipCode = eventDto.ZipCode,
                });
                if (result > 0)
                {
                    await _publishEndpoint.Publish<EventDto>(new()
                    {
                        EventName = eventDto.EventName,
                        City = eventDto.City,
                        State = eventDto.State,
                        Country = eventDto.Country,
                        StartDate = eventDto.StartDate,
                        EndDate = eventDto.EndDate,

                    });
                    return Created();
                }
                else
                {
                    return BadRequest();
                }
            }
            catch (Exception)
            {
                return BadRequest();
                throw;
            }
        }
    }
}
