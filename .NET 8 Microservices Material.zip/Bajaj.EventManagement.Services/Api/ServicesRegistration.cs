﻿using MassTransit;

namespace Api;

public static class ServicesRegistration
{
    public static IServiceCollection AddCommonServices(this IServiceCollection services)
    {
        services.AddMassTransit(x =>
        {
            x.UsingRabbitMq();
        });
        return services;
    }
}
