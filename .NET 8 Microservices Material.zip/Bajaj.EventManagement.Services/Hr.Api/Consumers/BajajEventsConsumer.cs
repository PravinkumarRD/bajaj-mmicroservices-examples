﻿using Api.Dtos;
using MassTransit;
using System.Text.Json;

namespace EventManager.Api.Consumers;

public class EventManagerConsumer : IConsumer<EventDto>
{
    public EventManagerConsumer()
    {

    }
    public async Task Consume(ConsumeContext<EventDto> context)
    {
        var jsonMessage = JsonSerializer.Serialize(context.Message);
        await Console.Out.WriteLineAsync($"Producer Message - {jsonMessage}");
    }
}
