﻿using EventManager.Api.Consumers;
using MassTransit;
using Microsoft.AspNetCore.Mvc;

namespace Hr.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BajajEventsConsumerController : ControllerBase
    {
        [HttpGet]
        public async Task<ActionResult> Get()
        {
            var busControl = Bus.Factory.CreateUsingRabbitMq(config =>
            {
                config.ReceiveEndpoint("new-event-created", e =>
                {
                    e.Consumer<EventManagerConsumer>();
                });
            });
            await busControl.StartAsync(new CancellationToken());
            return Ok();
        }
    }
}
