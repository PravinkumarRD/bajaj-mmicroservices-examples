﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Infrastructure.Migrations
{
    /// <inheritdoc />
    public partial class InitialMigration : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Events",
                columns: table => new
                {
                    EventId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    EventName = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    EventPeriod_StartDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    EventPeriod_EndDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    EventDescription = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: false),
                    Venu_Line1 = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Venu_Line2 = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Venu_City = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Venu_State = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Venu_Zipcode = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Venu_Country = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    SeatsFilled = table.Column<int>(type: "int", nullable: false),
                    Fees = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    Logo = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Events", x => x.EventId);
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Events");
        }
    }
}
