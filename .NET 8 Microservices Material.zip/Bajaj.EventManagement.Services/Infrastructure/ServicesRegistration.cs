﻿using Domain.Contracts;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace Infrastructure;

public static class ServicesRegistration
{
    public static IServiceCollection AddInfrastructureServices(this IServiceCollection services,IConfigurationManager configuration)
    {
        services.AddDbContext<EventsDbContext>(ctx =>
        {
            ctx.UseSqlServer(configuration.GetConnectionString("BajajEventsDbConStr"));
        });
        services.AddTransient<IEventRepository, EventRepository>();
        return services;
    }
}

