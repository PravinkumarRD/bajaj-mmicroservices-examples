﻿using Domain.Contracts;
using Domain.Entities;
using Microsoft.EntityFrameworkCore;

namespace Infrastructure;

public class EventRepository(EventsDbContext _context) : IEventRepository
{
    public async Task<List<Event>> GetAllAsync()
    {
        return await _context.Events.ToListAsync();
    }

    public async Task<Event> GetDetailsByIdAsync(int id)
    {
        return await _context.Events.FindAsync(id);
    }
    public async Task<int> AddAsync(Event entity)
    {
        _context.Events.Add(entity);
        return await _context.SaveChangesAsync();
    }
    public async Task<int> UpdateAsync(Event entity)
    {
        _context.Entry(entity).State = EntityState.Modified;
        return await _context.SaveChangesAsync();
    }
    public async Task<int> DeleteAsync(int id)
    {
        var entity = await _context.Events.FindAsync(id);
        if (entity == null)
        {
            return 0;
        }
        _context.Events.Remove(entity);
        return await _context.SaveChangesAsync();
    }
}
