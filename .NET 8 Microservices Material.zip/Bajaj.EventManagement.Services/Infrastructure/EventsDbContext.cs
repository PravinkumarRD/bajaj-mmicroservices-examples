﻿using Domain.Entities;
using Microsoft.EntityFrameworkCore;

namespace Infrastructure;

public class EventsDbContext:DbContext
{
    public EventsDbContext()
    {
        
    }
    public EventsDbContext(DbContextOptions options):base(options)
    {
        
    }
    public DbSet<Event> Events { get; set; }
    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        if (!optionsBuilder.IsConfigured)
        {
            optionsBuilder.UseSqlServer("Data Source=localhost;Initial Catalog=BajajEventsDb; Trusted_Connection=true;TrustServerCertificate=true;");
        }
    }
}
