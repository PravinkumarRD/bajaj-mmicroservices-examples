﻿using Confluent.Kafka;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Product.Api.Models;
using System.Text.Json;
namespace Product.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductsController(IProducer<string, string> _producer) : ControllerBase
    {
        [HttpPost("CreateProduct")]
        [Authorize(Roles = "Administrator")]
        public async Task<IActionResult> CreateProduct(CommercialProduct product)
        {
            //DB Code where you will store/save product
            var message = new Message<string, string>
            {
                Key = Guid.NewGuid().ToString(),
                Value = JsonSerializer.Serialize(product)
            };

            await _producer.ProduceAsync("products-topic", message);
            return Ok(new { ProductId = message.Key, Announcement = "New Commercial Product Registered!" });
        }
    }
}
