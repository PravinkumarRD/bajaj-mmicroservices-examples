﻿using Confluent.Kafka;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Text.Json;

namespace Catalog.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CatalogsController(IConsumer<string, string> _consumer) : ControllerBase
    {

        [HttpGet]
        [Authorize(Roles ="Administrator")]
        public ActionResult Get()
        {
            return Ok(new { Message = "Welcome To Bajaj!" });
        }
        [HttpGet("commercial-products")]
        [Authorize(Roles = "Customer")]
        public IActionResult CheckCommercialProductsAnnouncemnt()
        {
            _consumer.Subscribe("products-topic");

            var cancellationTokenSource = new CancellationTokenSource();
            var token = cancellationTokenSource.Token;

            Task.Run(() =>
            {
                try
                {
                    while (true)
                    {
                        var productAnnounceMessage = _consumer.Consume(token);
                        if (productAnnounceMessage != null)
                        {
                            var productInfo = JsonSerializer.Serialize(productAnnounceMessage.Message.Value);
                            Console.WriteLine($"New Product - {productInfo} has been added with Id - {productAnnounceMessage.Message.Key}!");
                        }

                    }
                }
                catch (ConsumeException e)
                {
                    Console.WriteLine($"Error occurred: {e.Error.Reason}");
                }
            });

            return Ok();
        }
    }
}
