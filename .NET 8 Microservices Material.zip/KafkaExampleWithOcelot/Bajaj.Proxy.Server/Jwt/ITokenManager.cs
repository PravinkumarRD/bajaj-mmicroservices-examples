﻿using Bajaj.Proxy.Server.Models;

namespace Bajaj.Proxy.Server.Jwt;

public interface ITokenManager
{
    string GenerateToken(User user, string roleName);
}
