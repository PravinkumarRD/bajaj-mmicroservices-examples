﻿namespace Bajaj.Proxy.Server.Models
{
    public class User
    {
        public string Email { get; set; } = "varun.patil@bajaj.com";
        public string Password { get; set; } = "Welcome@123";
        public string Role { get; set; } = "Administrator";
    }
}
