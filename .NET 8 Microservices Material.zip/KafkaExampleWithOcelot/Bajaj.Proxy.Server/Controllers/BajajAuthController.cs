﻿using Bajaj.Proxy.Server.Jwt;
using Bajaj.Proxy.Server.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Bajaj.Proxy.Server.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BajajAuthController(ITokenManager _tokenManager) : ControllerBase
    {
        private static List<User> _users = [new User() { Email = "alisha.c@bajaj.com", Password = "Welcome@123", Role = "Administrator" }, new User() { Email = "manish.kaushik@bajaj.com", Password = "Welcome@123", Role = "Customer" }];

        [HttpPost("CheckCredentials")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public ActionResult<string> GetDetails(User user)
        {
            var authUser = _users.Find(u => u.Email == user.Email && u.Password == user.Password);
            if (authUser == null)
            {
                return NotFound();
            }
            var authResponse = _tokenManager.GenerateToken(authUser, authUser.Role);
            return Ok(new { Token = authResponse });
        }
    }
}
